"""
Minecraft Guard Bot - Python 3.10.0
Server: funark.aternos.me:57003
Admin: RealWangLing

Kya karta hai ye bot:
  - Server se automatically connect hota hai
  - Admin ke saath dog ki tarah rehta hai
  - Admin ke paas aane wale mobs ko maarta hai
  - Agar mar jaaye to automatically respawn hota hai
  - Koi password nahi chahiye (offline mode)
"""

import time
import math
import sys
from javascript import require, On, AsyncTask, start

# ───── CONFIGURATION ─────────────────────────────────────────────────────────
HOST          = "funark.aternos.me"
PORT          = 57003
BOT_USERNAME  = "GuardBot"
ADMIN_NAME    = "RealWangLing"
VERSION       = "1.21.1"

FOLLOW_DIST   = 3      # Admin se kitni blocks ki duri par rukna hai
MOB_RANGE     = 12     # Admin ke kitne blocks andar mob detect ho

# Ye sab hostile mobs hain jinhe bot maarta hai
HOSTILE_MOBS  = {
    "zombie", "skeleton", "creeper", "spider", "cave_spider",
    "enderman", "witch", "pillager", "vindicator", "phantom",
    "drowned", "husk", "stray", "slime", "magma_cube", "blaze",
    "ghast", "wither_skeleton", "zombie_villager", "zombified_piglin",
    "hoglin", "zoglin", "piglin_brute", "silverfish", "ravager",
    "guardian", "elder_guardian", "shulker", "evoker", "vex",
}
# ─────────────────────────────────────────────────────────────────────────────

print("=" * 55)
print("  Minecraft Guard Bot Starting...")
print(f"  Server  : {HOST}:{PORT}")
print(f"  Bot Name: {BOT_USERNAME}")
print(f"  Admin   : {ADMIN_NAME}")
print("=" * 55)

# Libraries load karo
mineflayer = require("mineflayer")
pathfinder = require("mineflayer-pathfinder")
pvp_plugin = require("mineflayer-pvp").plugin
Vec3       = require("vec3")

Movements = pathfinder.Movements
goals     = pathfinder.goals

# ───── BOT BANAO ─────────────────────────────────────────────────────────────
bot = mineflayer.createBot({
    "host":     HOST,
    "port":     PORT,
    "username": BOT_USERNAME,
    "version":  VERSION,
    "auth":     "offline",      # Koi Microsoft login nahi chahiye
    "checkTimeoutInterval": 60000,
})

bot.loadPlugin(pathfinder.pathfinder)
bot.loadPlugin(pvp_plugin)

# ───── EVENTS ─────────────────────────────────────────────────────────────────

@On(bot, "login")
def on_login(*args):
    print("[✓] Server se connect ho gaya!")

@On(bot, "spawn")
def on_spawn(*args):
    print(f"[✓] Bot spawn ho gaya! Admin '{ADMIN_NAME}' ko dhundh raha hun...")
    bot.chat(f"Namaste! Main {ADMIN_NAME} ka guard hun. Mobs se protect karunga!")

@On(bot, "death")
def on_death(*args):
    print("[!] Bot mar gaya! Respawn ho raha hai...")

@On(bot, "respawn")
def on_respawn(*args):
    print("[✓] Bot wapas aa gaya (respawn)!")
    time.sleep(1)
    bot.chat("Main wapas aa gaya! Admin ko dhundh raha hun.")

@On(bot, "kicked")
def on_kicked(this, reason, *args):
    print(f"[!] Bot kick ho gaya: {reason}")
    print("    5 second baad reconnect karega...")
    time.sleep(5)
    restart_bot()

@On(bot, "error")
def on_error(this, err, *args):
    print(f"[!] Error aayi: {err}")

@On(bot, "end")
def on_end(this, reason, *args):
    print(f"[!] Connection band ho gayi: {reason}")
    print("    10 second baad reconnect karega...")
    time.sleep(10)
    restart_bot()

@On(bot, "chat")
def on_chat(this, username, message, *args):
    if username == bot.username:
        return
    msg = message.strip().lower()
    # Admin commands
    if username == ADMIN_NAME:
        if msg == "!come":
            bot.chat("Aa raha hun boss!")
            come_to_admin()
        elif msg == "!stop":
            bot.chat("Ruk gaya!")
            bot.pvp.stop()
            bot.pathfinder.setGoal(None)
        elif msg == "!status":
            pos = bot.entity.position
            hp  = bot.health
            food = bot.food
            bot.chat(f"HP:{hp:.0f} | Food:{food:.0f} | X:{pos.x:.0f} Y:{pos.y:.0f} Z:{pos.z:.0f}")
        elif msg == "!help":
            bot.chat("Commands: !come !stop !status !help")

# ───── HELPER FUNCTIONS ───────────────────────────────────────────────────────

def get_admin():
    """Admin ki entity return karo agar online ho"""
    player = bot.players.get(ADMIN_NAME)
    if player and player.entity:
        return player.entity
    return None

def distance_to(entity_a, entity_b):
    """Do entities ke beech distance calculate karo"""
    a = entity_a.position
    b = entity_b.position
    return math.sqrt((a.x - b.x)**2 + (a.y - b.y)**2 + (a.z - b.z)**2)

def come_to_admin():
    """Admin ke paas jao"""
    admin = get_admin()
    if not admin:
        return
    mvmt = Movements(bot)
    bot.pathfinder.setMovements(mvmt)
    bot.pathfinder.setGoal(goals.GoalFollow(admin, FOLLOW_DIST), True)

def find_nearest_hostile(admin_entity):
    """Admin ke paas ke sabse nazdiki hostile mob dhundo"""
    nearest     = None
    nearest_dist = MOB_RANGE

    for eid in bot.entities:
        entity = bot.entities[eid]
        if not entity or not entity.name:
            continue
        if entity.type != "mob":
            continue
        mob_name = entity.name.lower().replace(" ", "_")
        if mob_name not in HOSTILE_MOBS:
            continue

        dist = distance_to(admin_entity, entity)
        if dist < nearest_dist:
            nearest      = entity
            nearest_dist = dist

    return nearest

def attack_mob(mob):
    """Mob ko attack karo"""
    try:
        bot.pvp.attack(mob)
    except Exception:
        try:
            bot.attack(mob)
        except Exception as e:
            print(f"  [!] Attack nahi hua: {e}")

def restart_bot():
    """Bot ko restart karo"""
    print("[~] Bot restart ho raha hai...")
    try:
        import subprocess, os
        subprocess.Popen([sys.executable, __file__])
        os._exit(0)
    except Exception as e:
        print(f"[!] Restart mein dikkat: {e}")

# ───── MAIN GAME LOOP ─────────────────────────────────────────────────────────

@AsyncTask(start=True)
def main_loop(task):
    """Har 1 second mein chalega - follow + kill mobs"""
    loop_count = 0
    while True:
        task.sleep(1)
        loop_count += 1
        try:
            admin = get_admin()

            if not admin:
                # Admin offline hai - wait karo
                if loop_count % 15 == 0:
                    print(f"[~] Admin '{ADMIN_NAME}' abhi online nahi hai, wait kar raha hun...")
                continue

            # 1) Admin ke paas jao
            come_to_admin()

            # 2) Nearby hostile mob dhundo aur maaro
            mob = find_nearest_hostile(admin)
            if mob:
                mob_name = mob.name if mob.name else "mob"
                if loop_count % 3 == 0:
                    print(f"[⚔] '{mob_name}' ko maar raha hun!")
                attack_mob(mob)
            else:
                # Koi mob nahi - attack band karo aur follow karo
                try:
                    bot.pvp.stop()
                except Exception:
                    pass

            # 3) Health check - agar bhukha hai to eat karo
            if bot.food is not None and bot.food < 15:
                try:
                    bot.consume()
                except Exception:
                    pass

        except Exception as e:
            if loop_count % 10 == 0:
                print(f"[!] Loop error: {e}")

start()
